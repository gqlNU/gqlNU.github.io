rm(list=ls())
require(maptools)
require(spdep)

####   this assumes the zip file is unzipped into the C drive
####   so you should have the file malaria_sptm_data.RData
####   under the folder C:/malaria_section16_5/
workdir <- 'C:/malaria_section16_5/'
setwd(workdir)

####   load the space-time malaria data
load('malaria_sptm_data.RData')

####   read the shapefile in
shp <- readShapePoly('GulMalaria.shp')

####   construct the W matrix
Wl <- poly2nb(shp, queen=FALSE)
Wm <- nb2mat(Wl,style='B')

################################################################################
####   total number of cases from one's neighbours (excluding i itself)
####   NOTE: Wm is binary so that Wy computes the total (not the mean)
################################################################################
Wy <- fitdata$y
for (tt in 1:fitdata$nT) Wy[,tt] <- Wm %*% matrix(fitdata$y[,tt],ncol=1)

####   save the data with Wy
malaria$Wy <- Wy
save(file='malaria_sptm_data_with_Wy.RData')
