rm(list=ls())
require(maptools)
require(spdep)

workdir <- 'c:/'  # this assumes the shapefile is saved on your C drive
setwd(workdir)

####   load the space-time malaria data
load('malaria_sptm_data.RData')

####   read the shapefile in
shp <- readShapePoly('GulMalaria.shp')

####   construct the W matrix
Wl <- poly2nb(shp, queen=FALSE)
Wm <- nb2mat(Wl,style='B')

################################################################################
####   total number of cases from one's neighbours (excluding i itself)
####   NOTE: Wm is binary so that Wy computes the total (not the mean)
################################################################################
Wy <- fitdata$y
for (tt in 1:fitdata$nT) Wy[,tt] <- Wm %*% matrix(fitdata$y[,tt],ncol=1)

####   save the data with Wy
malaria$Wy <- Wy
save(file='malaria_sptm_data_with_Wy.RData')
