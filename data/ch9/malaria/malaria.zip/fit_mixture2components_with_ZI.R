####
####   This script fits the two-component mixture model
####   with zero-inflation (discussed in Section 9.4.5) for the 
####   village-level malaria data using WinBUGS.
####
####   The WinBUGS fit is done via the R2WinBUGS package
####   see www.sptmbook.com/r2winbugs.html for more detail on using this package
####
####   The output of this script will be analysed subsequently to obtain DIC for this model.
####   That is done in the R script DIC_calculation.R
####

rm(list=ls())
workdir <- 'c:/SpTmBook/ch9/'
setwd(workdir)
working.directory <- 'c:/SpTmBook/temp/'  #  a folder to store all intermediate output from WinBUGS
if (!dir.exists(working.directory)) dir.create(working.directory)
source('R_codes/setWinBUGSenv.R') 

####   define iterations to run 
####   (each MCMC chain is run for 500k iterations with to be 200k discarded as burn-in and thin=300)
tot.iters <- c(500000,200000,300)

####   specify where the WinBUGS script for the model is:
####   Type up the WinBUGS code in Figures 9.12 and 9.13 into a file called malaria_2components_ZI.txt
####   and save that file in c:/SpTmBook/temp/
model.file <- paste0(workdir,'malaria_2components_ZI.txt')

####   load the malaria data
load('malaria_spatial_ch9.RData')

####   setting initial values for the 2 chains
inits1 <- list(phi=0.1,alpha=c(-10,NA),delta=4,
               beta.rain=c(NA,rep(0.1,3)),g=rep(0,fitdata$N),
               p=c(0.1,NA),z=rbinom(fitdata$N,1,c(0.1,0.9))+1)
inits2 <- list(phi=0.2,alpha=c(-11,NA),delta=5,
               beta.rain=c(NA,rep(0.2,3)),g=rep(1,fitdata$N),
               p=c(0.2,NA),z=rbinom(fitdata$N,1,c(0.2,0.8))+1)
inits <- list(inits1,inits2)

####   specify parameters to be monitored
par2save <- c('alpha','g','z','p','phi','beta.rain','mu',
              'pred.proportion.zero','ppp','h','prob.h','deviance')

########################################################################
####    running model in WinBUGS
########################################################################
fits <- bugs(fitdata,inits, model.file = model.file
            ,parameters=par2save,n.chains = length(inits)
            ,n.iter = tot.iters[1], n.burnin = tot.iters[2],n.thin = tot.iters[3]
            ,bugs.directory=bugs.directory
#            ,WINE=WINE,WINEPATH=WINEPATH,useWINE=TRUE  #  this line is needed if WinBUGS is run on a Mac
            ,working.directory=working.directory,debug=TRUE)
########################################################################
####    save results
########################################################################
save.file <- 'malaria_sp_mixture2components_with_ZI.RData'
save(file=save.file,fits)
