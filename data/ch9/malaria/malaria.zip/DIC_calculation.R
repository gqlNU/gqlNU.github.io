####
####   This script calculates DIC for the two-component mixture model
####   with zero-inflation (discussed in Section 9.4.5) for the 
####   village-level malaria data.
####   
####   The two-component mixture model with zero-inflation needs to be run
####   first via R2WinBUGS (see the associated R script fit_mixture2components_with_ZI.R)
####

###    a function to calculate the log Poisson likelihood
poisson.loglikelihood <- function(y,mu) {
    if (y>0) l <- -mu + y*log(mu) - sum(log(1:y))
    if (y==0) {
        if (mu>0) l <- -mu + y*log(mu)
        if (mu==0) l <- 0.0000001
    }
    return(l)
}

###    load the results from WinBUGS fit (after running fit_mixture2components_with_ZI.R)
load('malaria_sp_mixture2components_with_ZI.RData')
 
#  the posterior mean of alpha
alpha <- fits$mean$alpha
#  the posterior means of the rain effect (rain is categorical)
beta.rain <- c(0,fits$mean$beta.rain)
log.mu <- rep(0,fitdata$n)
#   obtain the posterior medians of g and z for the DIC calculation
g <- apply(fits$sims.list$g,2,median)
z <- apply(fits$sims.list$z,2,median)
#   calculate the log of the Poisson mean
for (i in 1:fitdata$n) {
    log.mu[i] <- log(fitdata$pop[i]) +
                    beta.rain[fitdata$rain[i]] + 
                    alpha[clus[i]]
}

m <- exp(log.mu)*g  #   calculate m[i] on Line 7 in Figure 9.13
#   Dhat is the deviance calculated at the point estimates of the parameters
Dhat <- -2*sum(sapply(1:fitdata$n,function(x){poisson.loglikelihood(fitdata$O[x],m[x])}))
#   Dbar is the posterior mean of the deviance over the iterations 
#   (this is calculated within WinBUGS)
Dbar <- mean(fits$sims.list$deviance)
#   pD, the effective number of parameters
pD <- Dbar - Dhat
#   DIC
DIC <- Dbar + pD
#   putting Dbar, pD and DIC together for output
DIC.output <- c(Dbar,pD,DIC)
names(DIC.output) <- c('Dbar','pD','DIC')
DIC.output